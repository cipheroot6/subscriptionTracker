export default function Dashboard() {
  return (
    <div>
      <h1>Dashboard</h1>
      <p>Welcome to your subscription tracker.</p>
    </div>
  );
}
